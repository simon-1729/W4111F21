create view batting_summary as
select `lahmansbaseballdb`.`batting`.`playerID`                                           AS `playerID`,
       `lahmansbaseballdb`.`batting`.`AB`                                                 AS `ab`,
       `lahmansbaseballdb`.`batting`.`H`                                                  AS `H`,
       (((`lahmansbaseballdb`.`batting`.`H` - `lahmansbaseballdb`.`batting`.`HR`) -
         `lahmansbaseballdb`.`batting`.`2B`) - `lahmansbaseballdb`.`batting`.`3B`)        AS `1b`,
       `lahmansbaseballdb`.`batting`.`2B`                                                 AS `2b`,
       `lahmansbaseballdb`.`batting`.`3B`                                                 AS `3b`,
       `lahmansbaseballdb`.`batting`.`HR`                                                 AS `HR`,
       round((`lahmansbaseballdb`.`batting`.`H` / `lahmansbaseballdb`.`batting`.`AB`), 3) AS `batting_avg`
from `lahmansbaseballdb`.`batting`;

