create view career_batting as
select `lahmansbaseballdb`.`batting`.`playerID`                                                           AS `playerid`,
       sum(`lahmansbaseballdb`.`batting`.`AB`)                                                            AS `abs`,
       sum(`lahmansbaseballdb`.`batting`.`H`)                                                             AS `h`,
       sum(`lahmansbaseballdb`.`batting`.`RBI`)                                                           AS `rbi`,
       (sum(`lahmansbaseballdb`.`batting`.`H`) /
        if((sum(`lahmansbaseballdb`.`batting`.`AB`) = 0), NULL, sum(`lahmansbaseballdb`.`batting`.`AB`))) AS `avg`
from `lahmansbaseballdb`.`batting`
group by `lahmansbaseballdb`.`batting`.`playerID`;

