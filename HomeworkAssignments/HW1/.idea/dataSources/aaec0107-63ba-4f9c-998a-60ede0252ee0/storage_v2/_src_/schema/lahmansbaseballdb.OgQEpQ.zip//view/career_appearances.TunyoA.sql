create view career_appearances as
select `b`.`playerID`                           AS `playerID`,
       `lahmansbaseballdb`.`people`.`nameLast`  AS `nameLast`,
       `lahmansbaseballdb`.`people`.`nameFirst` AS `nameFirst`,
       sum(`b`.`G_all`)                         AS `games`
from (`lahmansbaseballdb`.`appearances` `b`
         join `lahmansbaseballdb`.`people` on ((`b`.`playerID` = `lahmansbaseballdb`.`people`.`playerID`)))
group by `b`.`playerID`;

